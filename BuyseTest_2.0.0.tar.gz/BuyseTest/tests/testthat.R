## * load packages
library(testthat)
library(BuyseTest)

library(lava)
library(data.table)
library(survival)

## * run tests
test_check("BuyseTest")
